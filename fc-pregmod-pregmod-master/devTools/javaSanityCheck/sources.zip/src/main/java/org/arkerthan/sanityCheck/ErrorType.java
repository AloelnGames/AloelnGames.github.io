package org.arkerthan.sanityCheck;

/**
 * @author Arkerthan
 */
public enum ErrorType {
    LOGIC,
    VARIABLE,
    MATCH;

    static ErrorType getErrorType(char c) {
        switch (c) {
            case 'L': //Logic
                return LOGIC;
            case 'S': //SpellCheck
                return MATCH;
            case 'O': //OnlyUsedOnce
                return VARIABLE;
        }
        throw new IllegalArgumentException("Unknown error type: " + c);
    }
}
