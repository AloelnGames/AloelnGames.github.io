package org.arkerthan.sanityCheck.logic;

import java.util.List;

/**
 * @param <E> Tag class to be stored
 * @author Arkerthan
 * <p>
 * Tag SearchTree stores Tags in an alphabetical search tree.
 * Once created the search tree can't be changed anymore.
 */
public class TagSearchTree<E extends Tag> {
    private static final int SIZE = 128;
    private final TagSearchTree<E>[] branches;
    private E element = null;
    private String path;

    /**
     * creates a new empty TagSearchTree
     */
    private TagSearchTree() {
        branches = new TagSearchTree[SIZE];
    }

    /**
     * Creates a new filled TagSearchTree
     *
     * @param list Tags to be inserted
     */
    public TagSearchTree(List<E> list) {
        this();
        for (E e : list) {
            this.add(e, 0);
        }
    }

    /**
     * adds a new Tag to the TagSearchTree
     *
     * @param e     Tag to be stored
     * @param index index of relevant char for adding in tag
     */
    private void add(E e, int index) {
        //set the path to here
        path = e.tag.substring(0, index);
        //checks if tag has to be stored here or further down
        if (e.tag.length() == index) {
            element = e;
        } else {
            //store tag in correct branch
            char c = e.tag.charAt(index);
            if (branches[c] == null) {
                branches[c] = new TagSearchTree<>();
            }
            branches[c].add(e, index + 1);
        }
    }

    /**
     * @param c character of branch needed
     * @return branch or null if branch doesn't exist
     */
    public TagSearchTree<E> getBranch(char c) {
        if (c >= SIZE) return null;
        return branches[c];
    }

    /**
     * @return stored Tag, null if empty
     */
    public E getElement() {
        return element;
    }

    /**
     * @return path inside full tree to get to this Branch
     */
    public String getPath() {
        return path;
    }
}
