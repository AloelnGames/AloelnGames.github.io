package org.arkerthan.sanityCheck.logic;

/**
 * @author Arkerthan
 */
public class DisallowedTagException extends RuntimeException {

    public DisallowedTagException(String tag) {
        super(tag);
    }
}
