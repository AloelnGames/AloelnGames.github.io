package org.arkerthan.sanityCheck.stringMatcher;

import org.arkerthan.sanityCheck.Error;
import org.arkerthan.sanityCheck.ErrorType;
import org.arkerthan.sanityCheck.Position;

/**
 * @author Arkerthan
 */
public class MatchError implements Error {
    private final String message;
    private final Position position;

    public MatchError(String message, Position p) {
        this.message = message;
        position = p;
    }

    @Override
    public String getErrorMessage() {
        return "Spellcheck  : " + position + ": Found " + message;
    }

    @Override
    public Position getPosition() {
        return position;
    }

    @Override
    public ErrorType getErrorType() {
        return ErrorType.MATCH;
    }
}
