package org.arkerthan.sanityCheck.variable;

import org.arkerthan.sanityCheck.Error;
import org.arkerthan.sanityCheck.ErrorType;
import org.arkerthan.sanityCheck.Position;

import java.util.LinkedList;
import java.util.List;

import static org.fusesource.jansi.Ansi.ansi;

/**
 * @author Arkerthan
 * <p>
 * Tag SearchTree stores Tags in an alphabetical search tree.
 * Only ASCII chars are allowed
 */
public class VariableSearchTree {
    private static final String ONLY_USED_ONCE = ansi().fgYellow().bold().a("OnlyUsedOnce").reset().toString();

    private static final int SIZE = 128;
    private final VariableSearchTree[] branches;
    private Element element = null;

    /**
     * creates a new empty VariableSearchTree
     */
    public VariableSearchTree() {
        branches = new VariableSearchTree[SIZE];
    }

    /**
     * adds a new Variable to the VariableSearchTree
     *
     * @param p       Position of variable
     * @param s       Variable to be stored
     * @param index   index of relevant char for adding in Variable
     * @param checked if the variable should be ignored if no second occurrence
     */
    private void add(Position p, String s, int index, boolean checked, boolean ignored) {
        //checks if variable has to be stored here or further down
        if (s.length() == index) {
            if (element == null) {
                element = new Element(p, s, checked, ignored);
            } else {
                element.count++;
            }
        } else {
            //store tag in correct branch
            char c = s.charAt(index);
            if (branches[c] == null) {
                branches[c] = new VariableSearchTree();
            }
            branches[c].add(p, s, index + 1, checked, ignored);
        }
    }


    /**
     * adds a new Variable to the VariableSearchTree
     *
     * @param p       Position of variable
     * @param s       Variable to be stored
     * @param checked if the variable should be ignored if no second occurrence
     * @param ignored if the variable comes from the ignored list
     */
    public void add(Position p, String s, boolean checked, boolean ignored) {
        add(p, s, 0, checked, ignored);
    }

    /**
     * adds a new Variable to the VariableSearchTree
     *
     * @param p       Position of variable
     * @param s       Variable to be stored
     * @param checked if the variable should be ignored if no second occurrence
     */
    public void add(Position p, String s, boolean checked) {
        this.add(p, s, 0, checked, false);
    }

    /**
     * Searches the tree for entries with a count of one and adds them to a given list.
     *
     * @param list list where errors should be added to.
     */
    private void getErrors(List<Error> list) {
        if (element != null) {
            if (element.count <= 1 && element.checked) {
                //variable only appears once and is not in an ignored code part
                list.add(new Error() {
                    @Override
                    public String getErrorMessage() {
                        return ONLY_USED_ONCE + ": " + element.firstPosition.toString() + ": "
                                + element.variable;
                    }

                    @Override
                    public Position getPosition() {
                        return element.firstPosition;
                    }

                    @Override
                    public ErrorType getErrorType() {
                        return ErrorType.VARIABLE;
                    }
                });
            } else if (element.ignored && element.count > 2) {
                //variable found more than once, but is being ignored
                list.add(new Error() {
                    @Override
                    public String getErrorMessage() {
                        return ONLY_USED_ONCE + ": Ignored but found more than once: " + element.variable;
                    }

                    @Override
                    public Position getPosition() {
                        return Position.LOADING;
                    }

                    @Override
                    public ErrorType getErrorType() {
                        return ErrorType.VARIABLE;
                    }
                });
            }
        }
        for (VariableSearchTree b :
                branches) {
            if (b != null) {
                b.getErrors(list);
            }
        }
    }

    /**
     * @return errors of onlyUsedOnce instances
     */
    public List<Error> getErrors() {
        List<Error> list = new LinkedList<>();
        getErrors(list);
        return list;
    }

    private static class Element {
        final Position firstPosition;
        final String variable;
        final boolean checked;
        final boolean ignored;
        int count;

        public Element(Position position, String variable, boolean checked, boolean ignored) {
            this.firstPosition = position;
            this.variable = variable;
            this.checked = checked;
            this.ignored = ignored;
            count = 1;
        }
    }
}
