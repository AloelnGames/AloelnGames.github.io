package org.arkerthan.sanityCheck;

/**
 * @author Arkerthan
 */
public interface Error extends Comparable<Error> {

    /**
     * @return the error message
     */
    String getErrorMessage();

    /**
     * @return position the error occurred
     */
    Position getPosition();

    ErrorType getErrorType();

    @Override
    default int compareTo(Error e) {
        /*int c = getErrorType().compareTo(((Error) o).getErrorType());
        if (c != 0) return c;*/

        return getPosition().compareTo(e.getPosition());
    }
}
