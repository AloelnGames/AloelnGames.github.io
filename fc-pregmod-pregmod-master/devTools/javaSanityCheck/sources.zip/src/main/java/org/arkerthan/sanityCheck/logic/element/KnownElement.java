package org.arkerthan.sanityCheck.logic.element;

/**
 * @author Arkerthan
 */
public abstract class KnownElement extends Element {

    /**
     * @param line at which it begins
     * @param pos  at which it begins
     */
    public KnownElement(int line, int pos) {
        super(line, pos);
    }

    /**
     * @return true, if it needs another Known Element to close it.
     */
    public abstract boolean isOpening();

    /**
     * @return true if it closes another Element.
     */
    public abstract boolean isClosing();

    /**
     * @param k Element to be checked
     * @return true if given Element closes Element
     */
    public abstract boolean isMatchingElement(KnownElement k);

    @Override
    public int handleChar(char c) {
        return 0;
    }
}
